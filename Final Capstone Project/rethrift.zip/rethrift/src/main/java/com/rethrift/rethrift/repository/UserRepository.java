package com.rethrift.rethrift.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rethrift.rethrift.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {

}
