package com.rethrift.rethrift.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.rethrift.rethrift.entity.Item;
import com.rethrift.rethrift.repository.ItemRepository;

@Controller
public class ItemController {

    private final ItemRepository itemRepository;

    public ItemController(ItemRepository itemRepository) {
        this.itemRepository = itemRepository;
    }

    @GetMapping("/sell")
    public String showSellForm(Model model) {
        model.addAttribute("item", new Item());
        return "sell";
    }

    @PostMapping("/sell")
    public String createItem(@ModelAttribute Item item,
                             @RequestParam("imageFile") MultipartFile imageFile) throws IOException {

        if (item.getPrice() == null) {
            item.setPrice(0.0);
        }

        // Handle image upload to static/images
        if (imageFile != null && !imageFile.isEmpty()) {
            String fileName = System.currentTimeMillis() + "_" + imageFile.getOriginalFilename();
            Path uploadPath = Paths.get("src/main/resources/static/images");
            Files.createDirectories(uploadPath);
            Files.copy(imageFile.getInputStream(),
                    uploadPath.resolve(fileName),
                    StandardCopyOption.REPLACE_EXISTING);

            // this matches home/discover/cart, which expect imageUrl to be a resource path
            item.setImageUrl("/images/" + fileName);
        }

        item.setApproved(false);
        item.setDeleted(false);

        itemRepository.save(item);
        return "redirect:/discover";
    }
}
