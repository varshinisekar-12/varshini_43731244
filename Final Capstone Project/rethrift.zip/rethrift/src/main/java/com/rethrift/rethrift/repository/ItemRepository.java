package com.rethrift.rethrift.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rethrift.rethrift.entity.Item;

public interface ItemRepository extends JpaRepository<Item, Long> {

    // Homepage: only approved & not deleted
    List<Item> findByApprovedTrueAndDeletedFalse();

    // Admin list: newest first
    List<Item> findAllByOrderByCreatedAtDesc();
}
