package com.rethrift.rethrift.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.rethrift.rethrift.entity.Item;
import com.rethrift.rethrift.repository.ItemRepository;

@Controller
public class HomeController {

    private final ItemRepository itemRepository;

    public HomeController(ItemRepository itemRepository) {
        this.itemRepository = itemRepository;
    }

    @GetMapping("/")
    public String root() {
        return "redirect:/login";
    }

    @GetMapping("/home")
    public String home(Model model) {
        List<Item> items = itemRepository.findByApprovedTrueAndDeletedFalse();
        model.addAttribute("items", items);
        model.addAttribute("cartCount", 0); // temporary; replace with real count
        return "home";
    }

    @GetMapping("/discover")
    public String discover(Model model) {
        List<Item> items = itemRepository.findByApprovedTrueAndDeletedFalse();
        model.addAttribute("items", items);
        model.addAttribute("cartCount", 0); // same here
        return "discover";
    }
}
