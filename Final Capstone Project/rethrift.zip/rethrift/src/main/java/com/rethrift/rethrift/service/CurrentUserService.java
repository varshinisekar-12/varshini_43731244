package com.rethrift.rethrift.service;

import java.util.Optional;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.rethrift.rethrift.entity.User;
import com.rethrift.rethrift.repository.UserRepository;

@Service
public class CurrentUserService {

    private final UserRepository userRepository;

    public CurrentUserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public Optional<User> getCurrentUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || auth.getName() == null) {
            return Optional.empty();
        }
        String email = auth.getName(); // username = email
        return userRepository.findAll().stream()
                .filter(u -> email.equals(u.getEmail()))
                .findFirst();
    }
}

