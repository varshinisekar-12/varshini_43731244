package com.rethrift.rethrift.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.rethrift.rethrift.repository.ItemRepository;
import com.rethrift.rethrift.entity.Item;

@Controller
public class AdminController {

    private final ItemRepository itemRepository;

    public AdminController(ItemRepository itemRepository) {
        this.itemRepository = itemRepository;
    }

    @GetMapping("/admin")
    public String adminDashboard(Model model) {
        model.addAttribute("items", itemRepository.findAllByOrderByCreatedAtDesc());
        return "admin";
    }

    @PostMapping("/admin/approve/{id}")
    public String approveItem(@PathVariable Long id) {
        itemRepository.findById(id).ifPresent(item -> {
            item.setApproved(true);
            item.setDeleted(false);
            itemRepository.save(item);
        });
        return "redirect:/admin";
    }

    @PostMapping("/admin/reject/{id}")
    public String rejectItem(@PathVariable Long id) {
        itemRepository.findById(id).ifPresent(item -> {
            item.setApproved(false);
            item.setDeleted(true);
            itemRepository.save(item);
        });
        return "redirect:/admin";
    }
}

