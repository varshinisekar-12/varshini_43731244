package com.rethrift.rethrift.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.rethrift.rethrift.entity.CartItem;
import com.rethrift.rethrift.entity.Item;
import com.rethrift.rethrift.entity.User;
import com.rethrift.rethrift.repository.CartItemRepository;
import com.rethrift.rethrift.repository.ItemRepository;
import com.rethrift.rethrift.service.CurrentUserService;

@Controller
public class CartController {

    private final CartItemRepository cartItemRepository;
    private final ItemRepository itemRepository;
    private final CurrentUserService currentUserService;

    public CartController(CartItemRepository cartItemRepository,
                          ItemRepository itemRepository,
                          CurrentUserService currentUserService) {
        this.cartItemRepository = cartItemRepository;
        this.itemRepository = itemRepository;
        this.currentUserService = currentUserService;
    }

    // Add to cart: POST /cart/add with hidden itemId
    @PostMapping("/cart/add")
    public String addToCart(@RequestParam("itemId") Long itemId) {
        User user = currentUserService.getCurrentUser().orElse(null);
        if (user == null) {
            return "redirect:/login";
        }

        Item item = itemRepository.findById(itemId).orElse(null);
        if (item == null) {
            return "redirect:/discover";
        }

        CartItem cartItem = cartItemRepository.findByUserAndItemId(user, itemId)
                .orElseGet(() -> {
                    CartItem ci = new CartItem();
                    ci.setUser(user);
                    ci.setItem(item);
                    ci.setQuantity(0);
                    return ci;
                });

        cartItem.setQuantity(cartItem.getQuantity() + 1);
        cartItemRepository.save(cartItem);

        return "redirect:/cart";
    }

    // View cart
    @GetMapping("/cart")
    public String viewCart(Model model) {
        User user = currentUserService.getCurrentUser().orElse(null);
        if (user == null) {
            return "redirect:/login";
        }

        List<CartItem> cartItems = cartItemRepository.findByUser(user).stream()
                .filter(ci -> ci != null && ci.getItem() != null)
                .toList();
        model.addAttribute("cartItems", cartItems);

        double subtotal = cartItems.stream()
                .mapToDouble(ci -> {
                    Double price = ci.getItem().getPrice();
                    int qty = ci.getQuantity();
                    return (price != null ? price : 0.0) * qty;
                })
                .sum();

        model.addAttribute("subtotal", subtotal);
        model.addAttribute("cartCount", cartItems.size());

        return "cart";
    }

    // +/- quantity
    @PostMapping("/cart/update")
    public String updateCartItem(@RequestParam("itemId") Long itemId,
                                 @RequestParam("action") String action) {
        User user = currentUserService.getCurrentUser().orElse(null);
        if (user == null) {
            return "redirect:/login";
        }

        CartItem cartItem = cartItemRepository.findByUserAndItemId(user, itemId)
                .orElse(null);
        if (cartItem == null) {
            return "redirect:/cart";
        }

        int qty = cartItem.getQuantity();
        if ("increase".equals(action)) {
            qty++;
        } else if ("decrease".equals(action) && qty > 1) {
            qty--;
        }
        cartItem.setQuantity(qty);
        cartItemRepository.save(cartItem);

        return "redirect:/cart";
    }

    // Remove a line from cart
    @PostMapping("/cart/remove/{id}")
    public String removeFromCart(@PathVariable Long id) {
        cartItemRepository.deleteById(id);
        return "redirect:/cart";
    }

    // Show checkout page (address + summary)
    @GetMapping("/checkout")
    public String checkoutPage(Model model) {
        User user = currentUserService.getCurrentUser().orElse(null);
        if (user == null) {
            return "redirect:/login";
        }

        List<CartItem> cartItems = cartItemRepository.findByUser(user);
        double subtotal = cartItems.stream()
                .mapToDouble(ci -> {
                    Double price = ci.getItem().getPrice();
                    int qty = ci.getQuantity();
                    return (price != null ? price : 0.0) * qty;
                })
                .sum();

        model.addAttribute("cartItems", cartItems);
        model.addAttribute("subtotal", subtotal);
        model.addAttribute("cartCount", cartItems.size());

        return "checkout";
    }

    // After address form, go to "payment portal" page
    @PostMapping("/checkout")
    public String checkoutSubmit() {
        User user = currentUserService.getCurrentUser().orElse(null);
        if (user == null) {
            return "redirect:/login";
        }
        return "redirect:/payment";
    }

    // Fake payment portal (choose method, confirm)
    @GetMapping("/payment")
    public String paymentPage(Model model) {
        User user = currentUserService.getCurrentUser().orElse(null);
        if (user == null) {
            return "redirect:/login";
        }

        List<CartItem> cartItems = cartItemRepository.findByUser(user);
        double subtotal = cartItems.stream()
                .mapToDouble(ci -> {
                    Double price = ci.getItem().getPrice();
                    int qty = ci.getQuantity();
                    return (price != null ? price : 0.0) * qty;
                })
                .sum();

        model.addAttribute("cartItems", cartItems);
        model.addAttribute("subtotal", subtotal);
        model.addAttribute("cartCount", cartItems.size());

        return "payment";
    }

    // When "Pay" is clicked
    @PostMapping("/payment")
    public String paymentSubmit() {
        User user = currentUserService.getCurrentUser().orElse(null);
        if (user == null) {
            return "redirect:/login";
        }

        cartItemRepository.deleteByUser(user);
        return "redirect:/checkout/success";
    }

    @GetMapping("/checkout/success")
    public String checkoutSuccess() {
        return "checkout-success";
    }
}
