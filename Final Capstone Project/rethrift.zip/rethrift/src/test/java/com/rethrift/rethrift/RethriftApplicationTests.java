package com.rethrift.rethrift;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RethriftApplicationTests {

	@Test
	void contextLoads() {
	}

}
